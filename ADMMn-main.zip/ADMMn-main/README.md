# ADMMn
Codes for the article [An Extended ADMM for 3-Block Nonconvex Nonseparable Problems with Applications](https://arxiv.org/abs/2402.02193), includes all tested algorithms and experiments. 

Reference: Z. Liu. An Extended ADMM for 3-Block Nonconvex Nonseparable Problems with Applications. arXiv:2402.02193. 

Feel free to contact me at [my email](mailto:sjtu_lzk@sjtu.edu.cn) if you have any questions.
